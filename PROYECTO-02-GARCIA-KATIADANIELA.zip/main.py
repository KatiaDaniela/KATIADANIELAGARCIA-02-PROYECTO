import csv
import os
os.system('clear')
lista_datos=[]

with open("synergy_logistics_database.csv", "r") as archivo_csv:
  lector=csv.reader(archivo_csv)

  for linea in lector:
    lista_datos.append(linea)

#10 EXPORTACIONES MAS CONCURRIDAS

Frecuencia=[]
contadorExp=0
valorExpTotal=0
#exp = filtracion de exportaciones
for exp in lista_datos:
  if exp[1] == "Exports":
    rutaOrigen= exp[2]
    rutaDestino = exp[3]
    contadorExp+=1
    valorExp=int(exp[-1])
    valorExpTotal=valorExpTotal+valorExp
    estaEnFrecuencia=False
    for Fre in Frecuencia:
      if Fre[0]==rutaOrigen and Fre[1]==rutaDestino:
        estaEnFrecuencia=True
        break
    if  estaEnFrecuencia==False:
      Frecuencia.append([rutaOrigen, rutaDestino, 1,valorExp]) 
    else:
      Frecuencia.remove(Fre)
      Fre[2]+=1
      Fre[3]+=valorExp
      Frecuencia.append(Fre)
print("\t\t\t10 EXPORTACIONES MÁS CONCURRIDAS")
print("Origen                 Destino                 Frecuencia       %Ingresos")
print("_______________________________________________________________________")
Frecuencia.sort(reverse=True, key=lambda x:x[2])
contador10=0
sumaPorcentajes10=0
for exp10 in Frecuencia:
  print(f'{exp10[0]:20}    {exp10[1]:20}    {exp10[2]:10}       {(exp10[3]/valorExpTotal*100):5.2f}%')
  sumaPorcentajes10+=exp10[3]/valorExpTotal*100
  contador10+=1
  if contador10==10:
    break
print(sumaPorcentajes10)

#10 IMPORTACIONES MAS CONCURRIDAS
print("\t\t\t10 IMPORTACIONES MÁS CONCURRIDAS")
FrecuenciaImp=[]
valorImpTotal=0
#imp = filtracion de importaciones
for imp in lista_datos:
  if imp[1] == "Imports":
    rutaOrigen= imp[2]
    rutaDestino = imp[3]
    valorImp=int(imp[-1])
    valorImpTotal=valorImpTotal+valorImp
    estaEnFrecuencia=False
    for Fre in FrecuenciaImp:
      if Fre[0]==rutaOrigen and Fre[1]==rutaDestino:
        estaEnFrecuencia=True
        break
    if  estaEnFrecuencia==False:
      FrecuenciaImp.append([rutaOrigen, rutaDestino, 1, valorImp]) 
    else:
      FrecuenciaImp.remove(Fre)
      Fre[2]+=1
      Fre[3]+=valorImp
      FrecuenciaImp.append(Fre)

FrecuenciaImp.sort(reverse=True, key=lambda x:x[2])
contador10=0
sumaPorcentajes10=0
for imp10 in FrecuenciaImp:
  print(f'{imp10[0]:20}    {imp10[1]:20}    {imp10[2]:10}       {(imp10[3]/valorImpTotal*100):5.2f}%')
  sumaPorcentajes10+=imp10[3]/valorImpTotal*100
  contador10+=1
  if contador10==10:
    break
print(sumaPorcentajes10)

# problema #2, 3 medios de transporte mas utilizados para exportacion
diccionario_transporte={}
for linea in lista_datos:
  if linea[1]=='Exports':
    transporte=linea[-3]
    valorExp=int(linea[-1])
    if transporte not in diccionario_transporte:
      diccionario_transporte[transporte]=[1,valorExp]
    else:
      listaLocal=diccionario_transporte[transporte]
      listaLocal[0]=listaLocal[0]+1
      listaLocal[1]=listaLocal[1]+valorExp

lista_transporte=[]

for transporte in diccionario_transporte:
  listaLocal=diccionario_transporte[transporte]
  listaLocal.append(transporte)
  lista_transporte.append(listaLocal)
lista_transporte.sort(reverse=True, key=lambda x:x[1])
contador=0
print()
print("\n")
print("\t\t\tEXPORTACIÓN: 3 MEDIOS DE TRANSPORTE CON MÁS IMPORTES")
print("Trasnporte    Frecuencia    Importe Total")
print("__________________________________________________________________")
for medio in lista_transporte:
  print(f'{medio[2]:5}    {medio[0]:10}    {medio[1]:19.2f}')
  contador+=1
  if contador==3:
    break



# problema #2, 3 medios de transporte mas utilizados para importaciones
diccionario_transporte={}
for linea in lista_datos:
  if linea[1]=='Imports':
    transporte=linea[-3]
    valorImp=int(linea[-1])
    if transporte not in diccionario_transporte:
      diccionario_transporte[transporte]=[1,valorImp]
    else:
      listaLocal=diccionario_transporte[transporte]
      listaLocal[0]=listaLocal[0]+1
      listaLocal[1]=listaLocal[1]+valorImp

lista_transporte=[]

for transporte in diccionario_transporte:
  listaLocal=diccionario_transporte[transporte]
  listaLocal.append(transporte)
  lista_transporte.append(listaLocal)
lista_transporte.sort(reverse=True, key=lambda x:x[1])
contador=0
print()
print("\t\t\tIMPORTACIÓN: 3 MEDIOS DE TRANSPORTE CON MÁS IMPORTES")
print("Trasnporte    Frecuencia    Importe Total")
print("_______________________________________________________________________")
for medio in lista_transporte:
  print(f'{medio[2]:5}    {medio[0]:10}    {medio[1]:19.2f}')
  contador+=1
  if contador==3:
    break

#Problema 3 80% ingresos: EXPORTACIONES
print("\n\n")
print("\t\t\tEXPORTACIÓN: RUTAS REPRESENTANTES DEL 80% DE LOS INGRESOS")
print("Origen                 Destino                  Frecuencia    Porcentaje")
print("___________________________________________________________________________")
sumaPorcentajes=0
Frecuencia.sort(reverse=True, key=lambda x:x[3])
for exp in Frecuencia:
  print(f'{exp[0]:20}    {exp[1]:20}    {exp[2]:10}       {(exp[3]/valorExpTotal*100):5.2f}%')
  sumaPorcentajes+=exp[3]/valorExpTotal*100
  if sumaPorcentajes>=80:
    break
   
print(f'{sumaPorcentajes:70.2f}%')

#Problema 3 80% ingresos: IMPORTACIONES
print("\n\n")
print("\t\t\tIMPORTACIONES: RUTAS REPRESENTANTES DEL 80% DE LOS INGRESOS")
print("Origen                 Destino                  Frecuencia    Porcentaje")
print("___________________________________________________________________________")

FrecuenciaImp.sort(reverse=True, key=lambda x:x[3])
sumaPorcentajes=0
for imp in FrecuenciaImp:
  print(f'{imp[0]:20}    {imp[1]:20}    {imp[2]:10}       {(imp[3]/valorImpTotal*100):5.2f}%')
  sumaPorcentajes+=imp[3]/valorImpTotal*100
  if sumaPorcentajes>=80:
    break
   
print(f'{sumaPorcentajes:70.2f}%')




listaImp=[]
sumaPorcentajes=0.0
for linea in FrecuenciaImp:
  listaImp.append(linea[0]+"-"+linea[1])
  sumaPorcentajes+=linea[3]/valorImpTotal*100
  if sumaPorcentajes>=80:
    break
conjuntoImp=set(listaImp)
listaExp=[]
sumaPorcentajes=0.0
for linea in Frecuencia:
  listaExp.append(linea[0]+"-"+linea[1])
  sumaPorcentajes+=linea[3]/valorExpTotal*100
  if sumaPorcentajes>=80:
    break
conjuntoExp=set(listaExp)
interseccion=conjuntoExp.intersection(conjuntoImp)

print("__________paise con exportaciones e importaciones__________")
print(interseccion)

#conjuntoImp=set(lista)
#print(conjuntoOrigen)

